﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Web;
using System.Web.Mvc;
using System.Threading.Tasks;


namespace FinalProjectSite.Controllers
{
    public class QANDAController : Controller
    {
        // GET: QANDA

        public ActionResult QANDA()
        {
            return View();
        }
       
    }
}